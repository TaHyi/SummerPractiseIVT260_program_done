﻿using UnityEngine;
using System.Collections;

public class WinDoc : MonoBehaviour {

    public GUIStyle Button;
    public GUIStyle level;
    public Texture Texture;
    int playLevel;
    private float rotAngle = 0;
    private Vector2 pivotPoint;
    float time1, time2;
    // Use this for initialization
    void Start()
    {
        time1 = Time.time;
        PlayerPrefs.SetInt("show", 0);
        rotAngle = -90;
        if (PlayerPrefs.HasKey("level") == false)
        {
            PlayerPrefs.SetInt("level", 2);
            playLevel = 2;
        }
        else playLevel = PlayerPrefs.GetInt("level") +1;
    }

    // Update is called once per frame

    void OnGUI()
    {
        pivotPoint = new Vector2(Screen.width / 2, Screen.height / 2);
        GUIUtility.RotateAroundPivot(rotAngle, pivotPoint);
        GUI.DrawTexture(new Rect(Screen.width / 2 - Screen.width / 8, Screen.height / 7, Screen.width / 4, Screen.height / 4), Texture);
        if (GUI.Button(new Rect(Screen.width / 2 - Screen.width / 24, Screen.height / 2f, Screen.width / 12, Screen.height / 12), "", Button))
        {

            Application.LoadLevel(2);
        }

        if (GUI.Button(new Rect(Screen.width / 2 - Screen.width / 24, Screen.height / 2f + 2 * Screen.height / 14, Screen.width / 16, Screen.height / 7), "Next Level : " + playLevel.ToString(), level))
        {

            // rotAngle += 10;
        }
    }
    void Update()
    {
        time2 = Time.time;
        if (time2 - time1 > 5) Application.LoadLevel(2);
    }
}
