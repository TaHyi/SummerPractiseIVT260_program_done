using UnityEngine;
using System.Collections;

public class save 
{

	public int R;
	public int C;
	public int P;
	public save()
	{
		R = 0;
		C = 0;
		P = 0;
	}
	public save(int r,int c, int p)
	{
		R = r;
		C = c;
		P = p;
	}
}

