﻿using UnityEngine;
using System.Collections;

public class confirmDoc : MonoBehaviour {
    public GUIStyle Buttoncancel;
    public GUIStyle Buttonok;
    public Texture Texture;
    // Use this for initialization
    void Start()
    {
        PlayerPrefs.SetInt("show", 0);
    }

    // Update is called once per frame

    void OnGUI()
    {
        GUI.DrawTexture(new Rect(Screen.width / 3, Screen.height / 2 - Screen.height / 2.6f, Screen.width / 4, Screen.height / 1.3f), Texture);
        if (GUI.Button(new Rect(Screen.width / 2 - Screen.width / 24, Screen.height / 2f + Screen.height / 10 - Screen.height / 14, Screen.width / 16, Screen.height / 7), "", Buttonok))
        {
           // PlayerPrefs.DeleteKey("level");
            Application.LoadLevel(1);
        }
        if (GUI.Button(new Rect(Screen.width / 2 - Screen.width / 24, Screen.height / 2f - Screen.height / 10 - Screen.height / 14, Screen.width / 16, Screen.height / 7), "", Buttoncancel))
        {
            PlayerPrefs.SetInt("show", 1);
            Destroy(gameObject, 0);
        }
    }
}
