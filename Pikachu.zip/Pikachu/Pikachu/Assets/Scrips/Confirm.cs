﻿using UnityEngine;
using System.Collections;

public class Confirm : MonoBehaviour {
    public GUIStyle Buttoncancel;
    public GUIStyle Buttonok;
    public Texture Texture;
	// Use this for initialization
	void Start () {
        PlayerPrefs.SetInt("show", 0);
	}
	
	// Update is called once per frame

	void OnGUI()
	{
		GUI.DrawTexture(new Rect(Screen.width/2 - Screen.width/4 , Screen.height/7, Screen.width / 2, Screen.height/2), Texture);
        if (GUI.Button(new Rect(Screen.width / 2 - Screen.width / 24 - Screen.width / 11, Screen.height / 2f, Screen.width / 12, Screen.height / 12), "", Buttonok))
		{
          //  PlayerPrefs.DeleteKey("level");
			Application.LoadLevel(1);
		}
        if (GUI.Button(new Rect(Screen.width / 2 - Screen.width / 24 + Screen.width / 11, Screen.height / 2f, Screen.width / 12, Screen.height / 12), "", Buttoncancel))
        {
            PlayerPrefs.SetInt("show", 1);
            Destroy(gameObject, 0);
        }
	}
}
