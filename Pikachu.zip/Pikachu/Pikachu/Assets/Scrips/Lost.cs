﻿using UnityEngine;
using System.Collections;

public class Lost : MonoBehaviour {

    public GUIStyle Button;
    public Texture Texture;
    float time1,time2;
    // Use this for initialization
    void Start()
    {
        time1 = Time.time;
        PlayerPrefs.SetInt("show", 0);
        PlayerPrefs.DeleteKey("level");
    }

    // Update is called once per frame

    void OnGUI()
    {
        GUI.DrawTexture(new Rect(Screen.width / 2 - Screen.width / 8, Screen.height / 7, Screen.width / 4, Screen.height / 4), Texture);
        if (GUI.Button(new Rect(Screen.width / 2 - Screen.width / 24, Screen.height / 2f, Screen.width / 12, Screen.height / 12), "", Button))
        {

            Application.LoadLevel(1);
        }
    }
    void Update()
    {
        time2 = Time.time;
        if (time2 - time1 > 5) Application.LoadLevel(1);
    }
}
