﻿using UnityEngine;
using System.Collections;

public class MainMenu : MonoBehaviour {

    public Texture backgroundTexture;
    public GUIStyle ramdomFreeMode;

    public float buttonPlayGamePlaceX;
    public float buttonPlayGamePlacey;
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Application.LoadLevel(5);
        }
	}

    void OnGUI()
    {
        //display background
        GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), backgroundTexture);
        //display button
        if (GUI.Button(new Rect(Screen.width / 1.27f - Screen.width / 12, Screen.height / 2 - (Screen.height * .48f)/2, Screen.width * .09f, Screen.height * .48f), "", ramdomFreeMode))
        {
            Application.LoadLevel(2);
        }
    }
}
