﻿using UnityEngine;
using System.Collections;

public class firstScreen : MonoBehaviour {

    public Texture loading;
    public Texture loading1;
    public Texture Texture1;
    public Texture Texture2;
    public Texture Texture3;
    public Texture Texture1x;
    public Texture Texture2x;
    public Texture Texture3x;
    public Texture TexturebackGround;
    float time = 0 ;
    // Use this for initialization
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        time = Time.time;
        if (time > 1.5) loading1 = loading;
        if (time > 2) Texture1x = Texture1;
        if (time > 2.4f) Texture2x = Texture2;
        if (time > 2.8f) Texture3x = Texture3;
        if (time > 3.5) Application.LoadLevel(1);

    }
    void OnGUI()
    {
        GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), TexturebackGround);
        GUI.DrawTexture(new Rect(Screen.width / 1.7f, Screen.height / 2 - Screen.height / 4f, Screen.width / 12, Screen.height / 2f), loading1);

        GUI.DrawTexture(new Rect(Screen.width / 1.7f + Screen.width / 24, Screen.height / 2 - Screen.height / 4f - Screen.height / 30f, Screen.width / 80, Screen.height / 40f), Texture1x);
        GUI.DrawTexture(new Rect(Screen.width / 1.7f + Screen.width / 24, Screen.height / 2 - Screen.height / 4f - 2*Screen.height / 30f, Screen.width / 80, Screen.height / 40f), Texture2x);
        GUI.DrawTexture(new Rect(Screen.width / 1.7f + Screen.width / 24, Screen.height / 2 - Screen.height / 4f - 3*Screen.height / 30f, Screen.width / 80, Screen.height / 40f), Texture3x);
     
    }
}
