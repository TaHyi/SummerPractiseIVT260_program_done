﻿using UnityEngine;
using System.Collections;

public class Button : MonoBehaviour {
    public GUIStyle ramdomFreeMode;
    public Texture backgroundTexture;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
    void OnGUI()
    {
        GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), backgroundTexture);
        if (GUI.Button(new Rect(Screen.width -80, Screen.height/2, Screen.width *.06f, Screen.height * .1f), "Free Mode", ramdomFreeMode))
        {
            
            Map getmap = new Map();
            getmap.CheckAndSwapThings();
        }
    }
}
