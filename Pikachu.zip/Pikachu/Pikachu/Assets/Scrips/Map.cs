﻿using UnityEngine;
using System.Collections;
//loc

public class Map : MonoBehaviour {
	Object prefap_pikachu;
    Object prefap_backGround;
	int ROW, COL;
	public int[][] MAP; //ma tran pikachu
	public bool[][] SHIT; //dung de duyet khi dung thuat toan tim duong di , chua can quan tam
	public Vec2[][] SHIT_ROOT_POS; // thuật toán 
	public Vec2 POS1; // biến tạm, để biết con nào đang được chọn, 
	public Vec2 POS2; //biến tạm, để biết con được chọn thứ 2 là con nào,
	public Vector3[][] POS; // ma trận, vị trí của pikachu tương ứng, để xử lí cho nhanh, ko cần phải tính lại trong gameplay
	public static int MIN_X; // biên lưu thông tin vị trí nhỏ nhất của mảng pikachu
	public static int MIN_Y; // biên lưu thông tin vị trí nhỏ nhất của mảng pikachu
	public static int CELL_WIDH = 28; // chiều cao mặt định của một pikachu
    public static int CELL_HEIGHT = 32; // chiều dai mặt định của một pikachu
	//------------
	public Vec2 POS1_SAVE;
	static int[] DX = { 0, 0, -1, 1 };
	static int[] DY = { -1, 1, 0, 0 };
	static int[] D = { -1, 1 };
	Vec2 CheckShit_Fast_temp;
	public int POS1_SAVE_INDEX;
	public Vec2 POS_SAVE_MIDDLE;
	public Vector3[] checksame;
	public int[][] savepic;
    AudioSource soundkill, soundRong,soundChoise,soundReset,soundHelp,soundTime,soundBackGround;
    int overGame = 0;
    //------------
    float oldTime = 0;
    float newTime = 0;
    float midTime = 0;
    float tx;
//    float timeInMinutes = 0;
    float currentold = 0;
    float current = 0;
    float size = 2 * Screen.width * 0.155f;
    float tile_h;
    //--------------
    public GUIStyle ramdomFreeModex;
    public GUIStyle ramdomBackModex;
    public GUIStyle ramdomSeeModex;
    public GUIStyle ramdomSoundModex;
    public GUIStyle ramdomSoundOffx;

    public GUIStyle ramdomFreeMode;
    public GUIStyle ramdomBackMode;
    public GUIStyle ramdomSeeMode;
    public GUIStyle ramdomSoundMode;
    public GUIStyle ramdomSoundOff;

    public GUIStyle ramdomFreeMode2;
    public GUIStyle ramdomBackMode2;
    public GUIStyle ramdomSeeMode2;
    public GUIStyle ramdomSoundMode2;
    public GUIStyle ramdomSoundOff2;

    public GUIStyle ramdomSound;
    bool soundeff = true;
    public Texture timeReviewClock;
    public Texture timeReviewEdge;
    public Texture timeReviewBorder;
    public Texture timeReviewBlue;
    public Texture timeReviewGray;
    public Texture timeReviewRed;
	//banner
	public Texture timeReviewBanner;

    // number texture

    public Texture number00;
    public Texture number10;
    public Texture number20;
    public Texture number30;

    public Texture number0;
    public Texture number1;
    public Texture number2;
    public Texture number3;

    public Texture number0x;
    public Texture number1x;
    public Texture number2x;
    public Texture number3x;

     Texture numberSee;
     Texture numberReset;

    bool sound = false,Onsound=true;

    //------
    float heightt;
    float heighttOld;
    //-------
    Vec2 HINT_POS0;
    Vec2 HINT_POS1;
    int tcount;
    //-- draw a Line point to point
    float width = 5.0f;
    Color color = Color.red;
	// Use this for initialization
    public bool trigger = false;
    /// <summary>
    ///  Orientation screen
    bool leftright ;
    bool oldleftright;
    float StartPoint;
    /// </summary>
    bool[] checkRow;
    /// number view
    int see, reset;
    int tCheckPair;
    bool showCap = true;
    bool showCapOld = true;
    int show;
    GoogleMobileAdsDemoScript ads = new GoogleMobileAdsDemoScript();
	void Start ()
    {
        ads.RequestInterstitial();
        //ramdom checkpair
         
         if (!PlayerPrefs.HasKey("level"))
         {
             tCheckPair = 1;
         }
         else tCheckPair = Random.Range(1, 11);
         
        // tCheckPair = 11;
       // Application.LoadLevelAdditive(2);
        number00 = number0;
        number10 = number1;
        number20 = number2;
        number30 = number3;

        ramdomFreeModex = ramdomFreeMode2;
        ramdomBackModex = ramdomBackMode2;
        ramdomSoundModex = ramdomSoundMode2;
        ramdomSeeModex = ramdomSeeMode2;
        ramdomSoundOffx = ramdomSoundOff2;
        if (Input.deviceOrientation == DeviceOrientation.LandscapeLeft ||
       Input.deviceOrientation == DeviceOrientation.LandscapeRight)
        {
            leftright = true;
            oldleftright = true;

            number00 = number0;
            number10 = number1;
            number20 = number2;
            number30 = number3;

            ramdomFreeModex = ramdomFreeMode;
            ramdomBackModex = ramdomBackMode;
            ramdomSoundModex = ramdomSoundMode;
            ramdomSeeModex = ramdomSeeMode;
            ramdomSoundOffx = ramdomSoundOff;
        }
        else if (Input.deviceOrientation == DeviceOrientation.Portrait)
        {
            leftright = false;
            oldleftright = false;

            number00 = number0x;
            number10 = number1x;
            number20 = number2x;
            number30 = number3x;

            ramdomFreeModex = ramdomFreeMode2;
            ramdomBackModex = ramdomBackMode2;
            ramdomSoundModex = ramdomSoundMode2;
            ramdomSeeModex = ramdomSeeMode2;
            ramdomSoundOffx = ramdomSoundOff2;
        }
         tile_h = Screen.height / 9.7f;
        
        CELL_HEIGHT = (int)(tile_h / (ROW - 2));
		CELL_WIDH = (int)(tile_h / (COL - 2));
        heighttOld= tile_h * 7.5f;
		heightt =heighttOld;
		prefap_pikachu = Resources.Load("item");
        if (prefap_pikachu == null ) Debug.Log("199999999999999999999923");
		LMap(10, 16);
		RandomMap();
        Camera came = (Camera) GetComponent(typeof(Camera));
        came.orthographic = true;
        came.orthographicSize = tx;
        oldTime = Time.time;
        midTime = oldTime;
        currentold = Time.time;

        //--------

        PlayerPrefs.SetInt("show",1) ;
        see= reset=3;
        numberSee = numberReset = number3;

        AudioListener.pause = false;
	}
    void Awake()
    {
        AudioSource[] source = GetComponents<AudioSource>();
        soundkill = source[0];
        soundRong = source[1];
        soundChoise = source[2];
        soundReset = source[3];
        soundHelp = source[4];
        soundTime = source[5];

        tx = Screen.width * 0.155f;

    }
  
    void OnGUI()
    {
        if (soundeff)
        {
            ramdomSound = ramdomSoundModex;
        }
        else ramdomSound = ramdomSoundOffx;
        float x0, y0;
        x0 = 1 * CELL_WIDH + MIN_X;
        y0 =   MIN_Y + CELL_HEIGHT/2;
        x0 = x0 / size;
        y0 = -y0 / size;

        //StartPoint = (x0 * Screen.width) / (Screen.width * 1.0f / Screen.height) + Screen.width / 2 + CELL_WIDH;
        StartPoint = (y0 * Screen.height) + Screen.height / 2 - CELL_HEIGHT;
        //  StartPoint = (Screen.height/5.5f);
        if (POS1 != null && POS2 != null && POS_SAVE_MIDDLE != null)
        {

            drawALine();
          //  Debug.Log("toa do 1 :" + positionx.ToString() + " : " + positiony.ToString());

        }
        // view texture

		float t = Screen.width - Screen.width / 28 - (Screen.width / 16) / 2;
		float t2 = Screen.width - Screen.width / 28 - (Screen.width / 40) / 2;

        GUI.DrawTexture(new Rect(Screen.width / 100, StartPoint + heighttOld, Screen.width / 20, -heightt), timeReviewBlue);
        GUI.DrawTexture(new Rect(Screen.width / 100, StartPoint, Screen.width / 20, heighttOld), timeReviewBorder);


        if (GUI.Button(new Rect(t, Screen.height / 2  - 1 * Screen.height / 4, Screen.width / 16, Screen.width / 16), "", ramdomSeeModex))
        {
            see--;
            if (see >= 0)
            {
                if (Onsound)
                {
                    soundHelp.Play();
                }
                if (POS1 != null)
                {
                    DeSelect();
                }
                CheckAndSwapThings();
            }
            

            
        }

        GUI.DrawTexture(new Rect(t + Screen.width / 32 - 0.5f * Screen.width / 92, Screen.height / 2 - 1 * Screen.height / 4 + Screen.width / 32 - 0.5f * Screen.width / 92, Screen.width / 92, Screen.width / 92), numberSee);
		if (GUI.Button(new Rect(t, Screen.height / 2 - Screen.height/16, Screen.width / 16, Screen.width / 16), "", ramdomFreeModex))
        {
            reset--;
            if (reset >= 0)
            {
                if (Onsound)
                {
                    soundReset.Play();
                }
                
                ResetMap();
                
            }
           

        }
        GUI.DrawTexture(new Rect(t + Screen.width / 32 - 0.5f * Screen.width / 92, Screen.height / 2 - Screen.height / 16 + Screen.width / 32 - 0.5f * Screen.width / 92, Screen.width / 92, Screen.width / 92), numberReset);
        if (GUI.Button(new Rect(t, Screen.height / 2 + (Screen.height/4-2*Screen.height / 16), Screen.width / 16, Screen.width / 16), "", ramdomSound))
        {
            sound = !sound;
            AudioListener.pause = sound;
            soundeff = !soundeff ;
            Onsound = !Onsound;
        }
    }
	// Update is called once per frame
	void Update () {

        if (Input.GetKeyDown(KeyCode.Escape) && showCap && showCapOld)
        {
            
                if (leftright)
                {
                    Application.LoadLevelAdditive(4);

                }
                else
                {
                    Application.LoadLevelAdditive(8);

                }
                showCap = false;
            
		}
        
        // get input rotional Screen 
        
            if (Input.deviceOrientation == DeviceOrientation.LandscapeLeft ||
                Input.deviceOrientation == DeviceOrientation.LandscapeRight)
            {
                leftright = true;
                if (leftright != oldleftright)
                {
                    UseLandscapeLeftLayout();
                }
                oldleftright = true;

            }
            else if (Input.deviceOrientation == DeviceOrientation.Portrait)
            {
                leftright = false;
                if (leftright != oldleftright)
                {
                    UsePortraitLayout();
                }
                oldleftright = false;
            }
            if (see == 3)
            { numberSee = number30; }
            if (see == 2)
            { numberSee = number20; }
            if (see == 1)
            { numberSee = number10; }
            if (see == 0)
            { numberSee = number00; }

            if (reset == 3)
            { numberReset = number30; }
            if (reset == 2)
            { numberReset = number20; }
            if (reset == 1)
            { numberReset = number10; }
            if (reset == 0)
            { numberReset = number00; }


        newTime = Time.time;
        if (newTime - midTime > 1 && heightt>0)
        {
			heightt -= heighttOld/300;
            midTime = newTime;
        }
        if (midTime - oldTime > 100)
        {
            timeReviewBlue = timeReviewGray;
        }
        if (midTime - oldTime > 220)
        {
            timeReviewBlue = timeReviewRed;
        }
        if (newTime - oldTime > 285 && heightt>0 )
        {
            if (!soundTime.isPlaying)
            {
                soundTime.Play();
            }
            
        }
        if (heightt<0)
        {
            if (leftright)
            {
                AudioListener.pause = sound;
                Application.LoadLevelAdditive(6);
                showCapOld = false;
            }
            else
            {
                Application.LoadLevelAdditive(10);
                showCapOld = false;
            }
            ads.ShowInterstitial();
        }
       // Debug.Log(oldTime.ToString() + "inTime" + newTime.ToString() );
		if (Input.GetMouseButtonDown (0)) {

            show = PlayerPrefs.GetInt("show");
            //SpecialEffectsHelper.Instance.Explosion(new Vector3(positionx3, positiony3, 0f));
            Debug.Log("===" +  size.ToString());
            if (showCap == false) showCap = true;
          //
            
            //Debug.Log("toa do 2 :" + Input.mousePosition.x.ToString() + " : " + Input.mousePosition.y.ToString());
			
			float x = (Input.mousePosition.x - Screen.width / 2) / Screen.width * (Screen.width * 1.0f / Screen.height);
			float y = ((Input.mousePosition.y - Screen.height / 2) / Screen.height)  ;
			// lay toa do cua chuot click .
            x *= 2*tx;
            y *= 2 * tx;
			int mouse_col = (int)((x-MIN_X)/CELL_WIDH);
			int mouse_row = (int)((y - MIN_Y) / CELL_HEIGHT);
			//Debug.Log(mouse_col + " " + mouse_row);
            if (mouse_row <= 8 && mouse_col <= 14 && mouse_row >= 1 && mouse_col >= 1 && MAP[mouse_row][mouse_col] != -1 && show==1)
            {
			
			if(POS1 !=null && POS1.C == mouse_col && POS1.R == mouse_row)
			{
				DeSelect();
			}
			else
                if (POS1 == null)
			{
				Select(new Vec2(mouse_row, mouse_col));
			}
			else
			{
              //  Debug.Log("toa do chuot nhan : hang = " + mouse_row.ToString() + "  Cot = " + mouse_col.ToString());


                if (tCheckPair == 1 || tCheckPair == 6 || tCheckPair == 7 || tCheckPair == 8 || tCheckPair == 9 || tCheckPair == 10 || tCheckPair == 11)
                { CheckPair1(new Vec2(mouse_row, mouse_col)); }
                if (tCheckPair == 2)
                { CheckPair2(new Vec2(mouse_row, mouse_col)); }
                if (tCheckPair == 3)
                { CheckPair3(new Vec2(mouse_row, mouse_col)); }
                if (tCheckPair == 4)
                { CheckPair4(new Vec2(mouse_row, mouse_col)); }
                if (tCheckPair == 5)
                { CheckPair5(new Vec2(mouse_row, mouse_col)); }
				
                    
			}
            }
		}
		
	}
	void AddPikachu(int type,Vector3 pos,int width,int height)
	{
		GameObject g = Instantiate(prefap_pikachu) as GameObject;
		g.transform.parent = this.transform;
		g.transform.position = pos;
		Sprite sprite = Resources.Load("Images/item/item"+type, typeof(Sprite)) as Sprite;
		g.GetComponent<SpriteRenderer>().sprite = sprite;
		g.transform.localScale = new Vector3(Mathf.Abs(width * 1.0f / sprite.bounds.size.x), Mathf.Abs (- height * 1.0f / sprite.bounds.size.y), 1);
	}

    void AddPikachu2(int type, Vector3 pos, int width, int height)
    {
        GameObject g = Instantiate(prefap_pikachu) as GameObject;
        g.transform.parent = this.transform;
        g.transform.position = pos;
        
        Sprite sprite = Resources.Load("Images/item2/item" + type, typeof(Sprite)) as Sprite;
        g.GetComponent<SpriteRenderer>().sprite = sprite;
        g.transform.localScale = new Vector3(Mathf.Abs(width * 1.0f / sprite.bounds.size.x), Mathf.Abs(-height * 1.0f / sprite.bounds.size.y), 1);
       // g.transform.Rotate(0, 90, 0);
    }
    void AddBackGround(int type,int type2, Vector3 pos, int width, int height)
    {
        GameObject g = Instantiate(prefap_pikachu) as GameObject;
        g.transform.parent = this.transform;
        g.transform.position = pos;
        Sprite sprite = Resources.Load("Images/backGround/" + type + "." + type2, typeof(Sprite)) as Sprite;
        g.GetComponent<SpriteRenderer>().sprite = sprite;
        g.transform.localScale = new Vector3(Mathf.Abs(width * 1.0f / sprite.bounds.size.x), Mathf.Abs(-height * 1.0f / sprite.bounds.size.y), 1);
       // g.renderer.vis
    }
	
	public void LMap(int row, int col)
	{
		
		
		ROW = row;
		COL = col;
        checkRow = new bool[COL]; 
		MAP = new int[ROW][];
		savepic = new int[ROW][];
		SHIT = new bool[ROW][];
		SHIT_ROOT_POS = new Vec2[ROW][];
		POS = new Vector3[ROW][];
		
		MIN_X = -COL * CELL_WIDH / 2;
		MIN_Y = -(ROW ) * CELL_HEIGHT / 2;
		
		for (int i = 0; i < ROW; i++)
		{
			MAP[i] = new int[COL];
			savepic[i]= new int[COL];
			SHIT[i] = new bool[COL];
			SHIT_ROOT_POS[i] = new Vec2[COL];
			POS[i] = new Vector3[COL];
			for (int j = 0; j < COL; j++)
			{
				SHIT[i][j] = false;
				MAP[i][j] = -1;
				SHIT_ROOT_POS[i][j] = new Vec2();
				
				
				POS[i][j] = new Vector3(0, 0, 0);
				POS[i][j].x = MIN_X + j * CELL_WIDH + CELL_WIDH / 2;
				POS[i][j].y = MIN_Y + i * CELL_HEIGHT + CELL_HEIGHT / 2;
				POS[i][j].z =10f;
			}
			
			
			
		}
		//PrintMap();
		//RandomMap();
		//CheckAndSwapThings();
	}
	void RandomMap()
	{
        int numberPikachu =20;
        if (PlayerPrefs.HasKey("level"))
        {
            numberPikachu= PlayerPrefs.GetInt("level") +20;
        }
        if (numberPikachu > 39) numberPikachu = 39;
        Debug.Log("tong so pikachu : "+numberPikachu.ToString());
        int dem = 0;
        for (int i = 1; i < ROW - 1; i++)
        {
            for (int j = 1; j < COL - 1; j++)
            {
                MAP[i][j] = 1;
                dem++;

            }
        }
      //  Debug.Log("tong so pikachu" + dem);

		if (dem % 2 == 1) {
			Debug.LogError ("khong the la 1 so le");
			return;
		}
		
		int[] pool = new int[dem];

        for (int i = 0; i < dem / 2; i++)
        {
            pool[i] = Random.Range(0, numberPikachu);
            pool[i + dem / 2] = pool[i];
        }
        for (int i = 0; i < dem; i++)
        {
            int index1 = Random.Range(0, dem);
            int index2 = Random.Range(0, dem);
            int temp = pool[index1];
            pool[index1] = pool[index2];
            pool[index2] = temp;
        }

        for (int i = 0; i < dem / 2; i++)
        {
            int index1 = Random.Range(0, dem);
            int index2 = Random.Range(0, dem);
            int temp = pool[index1];
            pool[index1] = pool[index2];
            pool[index2] = temp;
        }

        int dempool = 0;
       

            for (int i = 1; i < ROW - 1; i++)
            {
                for (int j = 1; j < COL - 1; j++)
                {
                    dempool++;
                    //int indexw = Random.Range(0, 30);
                   
                    if (leftright)
                    {
                        AddPikachu(pool[dempool - 1], POS[i][j], CELL_WIDH, CELL_HEIGHT);
                    }
                    else
                    {
                        AddPikachu2(pool[dempool - 1], POS[i][j], CELL_WIDH, CELL_HEIGHT);
                    }
                    savepic[i][j] = pool[dempool - 1];

                }
            }
		
		
	}
	
	void Select(Vec2 pos)
	{
        if (Onsound)
        {
            soundChoise.Play();
        }
		POS1 = new Vec2(pos.R, pos.C);
		//Debug.Log("selected " + POS1.Print());
		//print ("selected " );
		Vector3 getpost1 = new Vector3(MIN_X + POS1.C * CELL_WIDH + CELL_WIDH / 2,MIN_Y + POS1.R * CELL_HEIGHT + CELL_HEIGHT / 2,10f);
		AddPikachu(993, getpost1, CELL_WIDH, CELL_HEIGHT);
        
		
	}
	void DeSelect()
	{
        Vector3 getpost1 = new Vector3(MIN_X + POS1.C * CELL_WIDH + CELL_WIDH / 2, MIN_Y + POS1.R * CELL_HEIGHT + CELL_HEIGHT / 2, 10f);
        if (leftright)
        {
            AddPikachu(savepic[POS1.R][POS1.C], getpost1, CELL_WIDH, CELL_HEIGHT);
        }
        else
        {
            AddPikachu2(savepic[POS1.R][POS1.C], getpost1, CELL_WIDH, CELL_HEIGHT);
        }
		POS1 = null;
		POS2 = null;
		//Debug.Log("DeSelect");
	}
    // choi theo binh thuong
    void CheckPair1(Vec2 pos)
    {
        current = Time.time;
        if (current - currentold > 0.4f || current == 0)
        {
            POS2 = new Vec2(pos.R, pos.C);

            //Debug.Log("CheckPair " + POS1.Print() +" and " + POS2.Print());


            // Debug.Log(MAP[POS1.R][POS1.C] + " " + MAP[POS2.R][POS2.C]);
            if (MAP[POS1.R][POS1.C] != MAP[POS2.R][POS2.C])
            {
                //Debug.Log ("KHONG PHAI LA 1 CAP");
            }
            else
                if (CheckpairOnly(POS1, POS2) != null && checkSame(POS1, POS2) == true && TraiTimBenLeCuaBangKieu(POS1, POS2) == true && MAP[POS1.R][POS1.C] != -1)
                {
                    particleSystem();
                    



                    overGame++;
                    if (overGame == 56)
                    {
                        if (PlayerPrefs.HasKey("level") == false)
                        {
                            PlayerPrefs.SetInt("level", 1);
                        }
                        else
                        {
                            PlayerPrefs.SetInt("level", PlayerPrefs.GetInt("level") + 1);
                        }
                        if (leftright)
                        {
                            Application.LoadLevelAdditive(7);
                            showCapOld = false;
                        }
                        else
                        {
                            Application.LoadLevelAdditive(9);
                            showCapOld = false;
                        }
                        ads.ShowInterstitial();
                    }
                    currentold = Time.time;
                    if (Onsound)
                    {
                        soundkill.Play();
                    }
                    //Debug.Log("la 1 cap");
                    Vector3 getpost1 = new Vector3(MIN_X + POS1.C * CELL_WIDH + CELL_WIDH / 2, MIN_Y + POS1.R * CELL_HEIGHT + CELL_HEIGHT / 2, 1f);
                    Vector3 getpost2 = new Vector3(MIN_X + POS2.C * CELL_WIDH + CELL_WIDH / 2, MIN_Y + POS2.R * CELL_HEIGHT + CELL_HEIGHT / 2, 1f);
                    //Vector3 getpost3 = new Vector3(MIN_X + POS_SAVE_MIDDLE.C * CELL_WIDH + CELL_WIDH / 2, MIN_Y + POS_SAVE_MIDDLE.R * CELL_HEIGHT + CELL_HEIGHT / 2, 1f);

                    AddPikachu(995, getpost1, CELL_WIDH, CELL_HEIGHT);
                    AddPikachu(995, getpost2, CELL_WIDH, CELL_HEIGHT);

                    // AddBackGround(POS1.R, POS1.C, getpost1, CELL_WIDH, CELL_HEIGHT);
                    // AddBackGround(POS2.R, POS2.C, getpost2, CELL_WIDH, CELL_HEIGHT);
                    //AddPikachu(994, getpost3, CELL_WIDH, CELL_HEIGHT);


                    MAP[POS1.R][POS1.C] = -1;
                    MAP[POS2.R][POS2.C] = -1;
                    savepic[POS1.R][POS1.C] = -1;
                    savepic[POS2.R][POS2.C] = -1;
                    CheckAndSwapThings1();
                    //Debug.Log("diem 1 :" + POS1.R.ToString() + " va " + POS1.C.ToString() + "diem 2 :" + POS2.R.ToString() + " va " + POS2.C.ToString()) ;
                }
                else
                {
                    // Debug.Log("khong thay dương di ");
                    Vector3 getpostx = new Vector3(MIN_X + POS1.C * CELL_WIDH + CELL_WIDH / 2, MIN_Y + POS1.R * CELL_HEIGHT + CELL_HEIGHT / 2, 10f);
                    if (leftright)
                    {
                        AddPikachu(savepic[POS1.R][POS1.C], getpostx, CELL_WIDH, CELL_HEIGHT);
                    }
                    else
                    {
                        AddPikachu2(savepic[POS1.R][POS1.C], getpostx, CELL_WIDH, CELL_HEIGHT);
                    }
                    if (Onsound)
                    {
                        soundRong.Play();
                    }
                    POS1 = null;
                    POS2 = null;
                }
            //  System.Threading.Thread.Sleep(3000);
             
             
        }
        // drawALine();
    }

	// choi theo kieu don sang phải
	void CheckPair2(Vec2 pos)
	{
        current = Time.time;
        if (current - currentold > 0.7f || current == 0)
        {
            POS2 = new Vec2(pos.R, pos.C);

            //Debug.Log("CheckPair " + POS1.Print() +" and " + POS2.Print());


            // Debug.Log(MAP[POS1.R][POS1.C] + " " + MAP[POS2.R][POS2.C]);
            if (MAP[POS1.R][POS1.C] != MAP[POS2.R][POS2.C])
            {
                //Debug.Log ("KHONG PHAI LA 1 CAP");
            }
            else
                if (CheckpairOnly(POS1, POS2) != null && checkSame(POS1, POS2) == true && TraiTimBenLeCuaBangKieu(POS1, POS2) == true && MAP[POS1.R][POS1.C] != -1)
                {
                    particleSystem();
                   /// for (int i = 0; i < COL; i++)
                   // { checkRow[i] = true; }
                        overGame++;
                    if (overGame == 56)
                    {
                        if (PlayerPrefs.HasKey("level") == false)
                        {
                            PlayerPrefs.SetInt("level", 1);
                        }
                        else
                        {
                            PlayerPrefs.SetInt("level", PlayerPrefs.GetInt("level") + 1);
                        }
                        if (leftright)
                        {
                            Application.LoadLevelAdditive(7);
                            showCapOld = false;
                        }
                        else
                        {
                            Application.LoadLevelAdditive(9);
                            showCapOld = false;
                        }
                    }
                    currentold = Time.time;
                    if (Onsound)
                    {
                        soundkill.Play();
                    }
                    //Debug.Log("la 1 cap");
                    Vector3 getpost1 = new Vector3(MIN_X + POS1.C * CELL_WIDH + CELL_WIDH / 2, MIN_Y + POS1.R * CELL_HEIGHT + CELL_HEIGHT / 2, 1f);
                    Vector3 getpost2 = new Vector3(MIN_X + POS2.C * CELL_WIDH + CELL_WIDH / 2, MIN_Y + POS2.R * CELL_HEIGHT + CELL_HEIGHT / 2, 1f);
                    
                    MAP[POS1.R][POS1.C] = -1;
                    MAP[POS2.R][POS2.C] = -1;
                    savepic[POS1.R][POS1.C] = -1;
                    savepic[POS2.R][POS2.C] = -1;
                    CheckAndSwapThings1();
                    int demx = 0;
                    for (int i = 1; i < ROW - 1; i++)
                    {
                        for (int k = 1; k < COL - 2; k++)
                        {
                            if (savepic[i][k] == -1)
                            {
                                demx++;
                            }
                        }
                        if (demx == 1)
                        {
                            for (int j = 1; j < COL - 2; j++)
                            {
                                if (savepic[i][j] == -1)
                                {
                                    savepic[i][j] = savepic[i][j + 1];
                                    savepic[i][j + 1] = -1;
                                }
                            }
                        }
                        else
                        {
                            for (int j = 1; j < COL - 2; j++)
                            {
                                if (savepic[i][j] == -1)
                                {
                                    savepic[i][j] = savepic[i][j + 1];
                                    savepic[i][j + 1] = -1;
                                }
                            }
                            for (int j = 1; j < COL - 2; j++)
                            {
                                if (savepic[i][j] == -1)
                                {
                                    savepic[i][j] = savepic[i][j + 1];
                                    savepic[i][j + 1] = -1;
                                }
                            }
                            for (int j = 1; j < COL - 2; j++)
                            {
                                if (savepic[i][j] == -1)
                                {
                                    savepic[i][j] = savepic[i][j + 1];
                                    savepic[i][j + 1] = -1;
                                }
                            }
 
                        }
                    }
                    
                    for (int i = 1; i < ROW - 1; i++)
                    {
                        for (int j = 1; j < COL - 1; j++)
                        {

                            if (savepic[i][j] != -1)
                            {
                                MAP[i][j] = 1;
                                if (leftright)
                                {
                                    AddPikachu(savepic[i][j], POS[i][j], CELL_WIDH, CELL_HEIGHT);
                                }
                                else
                                {
                                    AddPikachu2(savepic[i][j], POS[i][j], CELL_WIDH, CELL_HEIGHT);
                                }
                            }
                            else
                            {
                                MAP[i][j] = -1;
                                AddPikachu(995, POS[i][j], CELL_WIDH, CELL_HEIGHT);
                            }
                            

                        }
                    }

                    
                    //Debug.Log("diem 1 :" + POS1.R.ToString() + " va " + POS1.C.ToString() + "diem 2 :" + POS2.R.ToString() + " va " + POS2.C.ToString()) ;
                }
                else
                {
                    // Debug.Log("khong thay dương di ");
                    
                    Vector3 getpostx = new Vector3(MIN_X + POS1.C * CELL_WIDH + CELL_WIDH / 2, MIN_Y + POS1.R * CELL_HEIGHT + CELL_HEIGHT / 2, 10f);
                    if (leftright)
                    {
                        AddPikachu(savepic[POS1.R][POS1.C], getpostx, CELL_WIDH, CELL_HEIGHT);
                    }
                    else
                    {
                        AddPikachu2(savepic[POS1.R][POS1.C], getpostx, CELL_WIDH, CELL_HEIGHT);
                    }
                    POS1 = null;
                    POS2 = null;
                    if (Onsound)
                    {
                        soundRong.Play();
                    }
                }
            //  System.Threading.Thread.Sleep(3000);
        
        }
       // drawALine();
	}
    // choi theo kieu don sang trai
    void CheckPair3(Vec2 pos)
    {
        current = Time.time;
        if (current - currentold > 0.7f || current == 0)
        {
            POS2 = new Vec2(pos.R, pos.C);

            //Debug.Log("CheckPair " + POS1.Print() +" and " + POS2.Print());


            // Debug.Log(MAP[POS1.R][POS1.C] + " " + MAP[POS2.R][POS2.C]);
            if (MAP[POS1.R][POS1.C] != MAP[POS2.R][POS2.C])
            {
                //Debug.Log ("KHONG PHAI LA 1 CAP");
            }
            else
                if (CheckpairOnly(POS1, POS2) != null && checkSame(POS1, POS2) == true && TraiTimBenLeCuaBangKieu(POS1, POS2) == true && MAP[POS1.R][POS1.C] != -1)
                {
                    particleSystem();
                    /// for (int i = 0; i < COL; i++)
                    // { checkRow[i] = true; }
                    overGame++;
                    if (overGame == 56)
                    {
                        if (PlayerPrefs.HasKey("level") == false)
                        {
                            PlayerPrefs.SetInt("level", 1);
                        }
                        else
                        {
                            PlayerPrefs.SetInt("level", PlayerPrefs.GetInt("level") + 1);
                        }
                        if (leftright)
                        {
                            Application.LoadLevelAdditive(7);
                            showCapOld = false;
                        }
                        else
                        {
                            Application.LoadLevelAdditive(9);
                            showCapOld = false;
                        }
                    }
                    currentold = Time.time;
                    if (Onsound)
                    {
                        soundkill.Play();
                    }
                    //Debug.Log("la 1 cap");
                    Vector3 getpost1 = new Vector3(MIN_X + POS1.C * CELL_WIDH + CELL_WIDH / 2, MIN_Y + POS1.R * CELL_HEIGHT + CELL_HEIGHT / 2, 1f);
                    Vector3 getpost2 = new Vector3(MIN_X + POS2.C * CELL_WIDH + CELL_WIDH / 2, MIN_Y + POS2.R * CELL_HEIGHT + CELL_HEIGHT / 2, 1f);
                    //Vector3 getpost3 = new Vector3(MIN_X + POS_SAVE_MIDDLE.C * CELL_WIDH + CELL_WIDH / 2, MIN_Y + POS_SAVE_MIDDLE.R * CELL_HEIGHT + CELL_HEIGHT / 2, 1f);

                    // AddPikachu(995, getpost1, CELL_WIDH, CELL_HEIGHT);
                    //AddPikachu(995, getpost2, CELL_WIDH, CELL_HEIGHT);
                    MAP[POS1.R][POS1.C] = -1;
                    MAP[POS2.R][POS2.C] = -1;
                    savepic[POS1.R][POS1.C] = -1;
                    savepic[POS2.R][POS2.C] = -1;
                    CheckAndSwapThings1();
                    int demx = 0;
                    for (int i = 1; i < ROW - 1; i++)
                    {
                        for (int k = 1; k < COL - 0; k++)
                        {
                            if (savepic[i][k] == -1)
                            {
                                demx++;
                            }
                        }
                        if (demx == 1)
                        {
                            for (int j = COL - 1; j >1 ; j--)
                            {
                                if (savepic[i][j] == -1)
                                {
                                    savepic[i][j] = savepic[i][j - 1];
                                    savepic[i][j - 1] = -1;
                                }
                            }
                        }
                        else
                        {
                            for (int n = 0; n<3 ; n++)
                            {
                                
                            for (int j = COL - 1; j > 1; j--)
                            {
                                if (savepic[i][j] == -1)
                                {
                                    savepic[i][j] = savepic[i][j - 1];
                                    savepic[i][j - 1] = -1;
                                }
                            }
                            }

                        }
                    }

                    for (int i = 1; i < ROW - 1; i++)
                    {
                        for (int j = 1; j < COL - 1; j++)
                        {

                            if (savepic[i][j] != -1)
                            {
                                MAP[i][j] = 1;
                                if (leftright)
                                {
                                    AddPikachu(savepic[i][j], POS[i][j], CELL_WIDH, CELL_HEIGHT);
                                }
                                else
                                {
                                    AddPikachu2(savepic[i][j], POS[i][j], CELL_WIDH, CELL_HEIGHT);
                                }
                            }
                            else
                            {
                                MAP[i][j] = -1;
                                AddPikachu(995, POS[i][j], CELL_WIDH, CELL_HEIGHT);
                            }


                        }
                    }

                    
                    //Debug.Log("diem 1 :" + POS1.R.ToString() + " va " + POS1.C.ToString() + "diem 2 :" + POS2.R.ToString() + " va " + POS2.C.ToString()) ;
                }
                else
                {
                    // Debug.Log("khong thay dương di ");

                    Vector3 getpostx = new Vector3(MIN_X + POS1.C * CELL_WIDH + CELL_WIDH / 2, MIN_Y + POS1.R * CELL_HEIGHT + CELL_HEIGHT / 2, 10f);
                    if (leftright)
                    {
                        AddPikachu(savepic[POS1.R][POS1.C], getpostx, CELL_WIDH, CELL_HEIGHT);
                    }
                    else
                    {
                        AddPikachu2(savepic[POS1.R][POS1.C], getpostx, CELL_WIDH, CELL_HEIGHT);
                    }
                    POS1 = null;
                    POS2 = null;
                    if (Onsound)
                    {
                        soundRong.Play();
                    }
                }
            //  System.Threading.Thread.Sleep(3000);

        }
        // drawALine();
    }
    // kieu tren xuong
    void CheckPair4(Vec2 pos)
    {
        current = Time.time;
        if (current - currentold > 0.7f || current == 0)
        {
            POS2 = new Vec2(pos.R, pos.C);

            //Debug.Log("CheckPair " + POS1.Print() +" and " + POS2.Print());


            // Debug.Log(MAP[POS1.R][POS1.C] + " " + MAP[POS2.R][POS2.C]);
            if (MAP[POS1.R][POS1.C] != MAP[POS2.R][POS2.C])
            {
                //Debug.Log ("KHONG PHAI LA 1 CAP");
            }
            else
                if (CheckpairOnly(POS1, POS2) != null && checkSame(POS1, POS2) == true && TraiTimBenLeCuaBangKieu(POS1, POS2) == true && MAP[POS1.R][POS1.C] != -1)
                {
                    particleSystem();/// for (int i = 0; i < COL; i++)
                    // { checkRow[i] = true; }

                    overGame++;
                    if (overGame == 56)
                    {
                        if (PlayerPrefs.HasKey("level"))
                        {
                            
                            PlayerPrefs.SetInt("level", PlayerPrefs.GetInt("level") + 1);
                        }
                        else
                        {
                            PlayerPrefs.SetInt("level", 1);
                        }
                        if (leftright)
                        {
                            Application.LoadLevelAdditive(7);
                            showCapOld = false;
                        }
                        else
                        {
                            Application.LoadLevelAdditive(9);
                            showCapOld = false;
                        }
                    }
                    currentold = Time.time;
                    soundkill.Play();
                    //Debug.Log("la 1 cap");
                    Vector3 getpost1 = new Vector3(MIN_X + POS1.C * CELL_WIDH + CELL_WIDH / 2, MIN_Y + POS1.R * CELL_HEIGHT + CELL_HEIGHT / 2, 1f);
                    Vector3 getpost2 = new Vector3(MIN_X + POS2.C * CELL_WIDH + CELL_WIDH / 2, MIN_Y + POS2.R * CELL_HEIGHT + CELL_HEIGHT / 2, 1f);
                    //Vector3 getpost3 = new Vector3(MIN_X + POS_SAVE_MIDDLE.C * CELL_WIDH + CELL_WIDH / 2, MIN_Y + POS_SAVE_MIDDLE.R * CELL_HEIGHT + CELL_HEIGHT / 2, 1f);

                    // AddPikachu(995, getpost1, CELL_WIDH, CELL_HEIGHT);
                    //AddPikachu(995, getpost2, CELL_WIDH, CELL_HEIGHT);
                    MAP[POS1.R][POS1.C] = -1;
                    MAP[POS2.R][POS2.C] = -1;
                    savepic[POS1.R][POS1.C] = -1;
                    savepic[POS2.R][POS2.C] = -1;

                    int demx = 0;
                    for (int i = 1; i < COL - 1; i++)
                    {
                        for (int k = 1; k < ROW - 2; k++)
                        {
                            if (savepic[k][i] == -1)
                            {
                                demx++;
                            }
                        }
                        if (demx == 1)
                        {
                            for (int j = 1; j < ROW - 2; j++)
                            {
                                if (savepic[j][i] == -1)
                                {
                                    savepic[j][i] = savepic[j + 1][i];
                                    savepic[j + 1][i] = -1;
                                }
                            }
                        }
                        else
                        {
                            for (int j = 1; j < ROW - 2; j++)
                            {
                                if (savepic[j][i] == -1)
                                {
                                    savepic[j][i] = savepic[j + 1][i];
                                    savepic[j + 1][i] = -1;
                                }
                            }
                            for (int j = 1; j < ROW - 2; j++)
                            {
                                if (savepic[j][i] == -1)
                                {
                                    savepic[j][i] = savepic[j + 1][i];
                                    savepic[j + 1][i] = -1;
                                }
                            }

                        }
                    }

                    for (int i = 1; i < ROW - 1; i++)
                    {
                        for (int j = 1; j < COL - 1; j++)
                        {

                            if (savepic[i][j] != -1)
                            {
                                MAP[i][j] = 1;
                                if (leftright)
                                {
                                    AddPikachu(savepic[i][j], POS[i][j], CELL_WIDH, CELL_HEIGHT);
                                }
                                else
                                {
                                    AddPikachu2(savepic[i][j], POS[i][j], CELL_WIDH, CELL_HEIGHT);
                                }
                            }
                            else
                            {
                                MAP[i][j] = -1;
                                AddPikachu(995, POS[i][j], CELL_WIDH, CELL_HEIGHT);
                            }


                        }
                    }

                    CheckAndSwapThings1();
                    //Debug.Log("diem 1 :" + POS1.R.ToString() + " va " + POS1.C.ToString() + "diem 2 :" + POS2.R.ToString() + " va " + POS2.C.ToString()) ;
                }
                else
                {
                    // Debug.Log("khong thay dương di ");

                    Vector3 getpostx = new Vector3(MIN_X + POS1.C * CELL_WIDH + CELL_WIDH / 2, MIN_Y + POS1.R * CELL_HEIGHT + CELL_HEIGHT / 2, 10f);
                    if (leftright)
                    {
                        AddPikachu(savepic[POS1.R][POS1.C], getpostx, CELL_WIDH, CELL_HEIGHT);
                    }
                    else
                    {
                        AddPikachu2(savepic[POS1.R][POS1.C], getpostx, CELL_WIDH, CELL_HEIGHT);
                    }
                    POS1 = null;
                    POS2 = null;
                    soundRong.Play();
                }
            //  System.Threading.Thread.Sleep(3000);

        }
        // drawALine();
    }
    void CheckPair5(Vec2 pos)
    {
        current = Time.time;
        if (current - currentold > 0.7f || current == 0)
        {
            POS2 = new Vec2(pos.R, pos.C);

            //Debug.Log("CheckPair " + POS1.Print() +" and " + POS2.Print());


            // Debug.Log(MAP[POS1.R][POS1.C] + " " + MAP[POS2.R][POS2.C]);
            if (MAP[POS1.R][POS1.C] != MAP[POS2.R][POS2.C])
            {
                //Debug.Log ("KHONG PHAI LA 1 CAP");
            }
            else
                if (CheckpairOnly(POS1, POS2) != null && checkSame(POS1, POS2) == true && TraiTimBenLeCuaBangKieu(POS1, POS2) == true && MAP[POS1.R][POS1.C] != -1)
                {
                    particleSystem();
                    /// for (int i = 0; i < COL; i++)
                    // { checkRow[i] = true; }
                    overGame++;
                    if (overGame == 56)
                    {
                        if (PlayerPrefs.HasKey("level") == false)
                        {
                            PlayerPrefs.SetInt("level", 1);
                        }
                        else
                        {
                            PlayerPrefs.SetInt("level", PlayerPrefs.GetInt("level") + 1);
                        }
                        if (leftright)
                        {
                            Application.LoadLevelAdditive(7);
                            showCapOld = false;
                        }
                        else { 
                            Application.LoadLevelAdditive(9);
                            showCapOld = false;
                        }
                    }
                    currentold = Time.time;
                    soundkill.Play();
                    //Debug.Log("la 1 cap");
                    Vector3 getpost1 = new Vector3(MIN_X + POS1.C * CELL_WIDH + CELL_WIDH / 2, MIN_Y + POS1.R * CELL_HEIGHT + CELL_HEIGHT / 2, 1f);
                    Vector3 getpost2 = new Vector3(MIN_X + POS2.C * CELL_WIDH + CELL_WIDH / 2, MIN_Y + POS2.R * CELL_HEIGHT + CELL_HEIGHT / 2, 1f);
                    //Vector3 getpost3 = new Vector3(MIN_X + POS_SAVE_MIDDLE.C * CELL_WIDH + CELL_WIDH / 2, MIN_Y + POS_SAVE_MIDDLE.R * CELL_HEIGHT + CELL_HEIGHT / 2, 1f);

                    // AddPikachu(995, getpost1, CELL_WIDH, CELL_HEIGHT);
                    //AddPikachu(995, getpost2, CELL_WIDH, CELL_HEIGHT);
                    MAP[POS1.R][POS1.C] = -1;
                    MAP[POS2.R][POS2.C] = -1;
                    savepic[POS1.R][POS1.C] = -1;
                    savepic[POS2.R][POS2.C] = -1;

                    int demx = 0;
                    for (int i = 1; i < COL - 1; i++)
                    {
                        for (int k = 1; k < ROW - 0; k++)
                        {
                            if (savepic[k][i] == -1)
                            {
                                demx++;
                            }
                        }
                        if (demx == 1)
                        {
                            for (int j = ROW - 1; j > 1; j--)
                            {
                                if (savepic[j][i] == -1)
                                {
                                    savepic[j][i] = savepic[j - 1][i];
                                    savepic[j - 1][i] = -1;
                                }
                            }
                        }
                        else
                        {
                            for (int j = ROW - 1; j > 1; j--)
                            {
                                if (savepic[j][i] == -1)
                                {
                                    savepic[j][i] = savepic[j - 1][i];
                                    savepic[j - 1][i] = -1;
                                }
                            }
                            for (int j = ROW - 1; j > 1; j--)
                            {
                                if (savepic[j][i] == -1)
                                {
                                    savepic[j][i] = savepic[j - 1][i];
                                    savepic[j - 1][i] = -1;
                                }
                            }

                        }
                    }

                    for (int i = 1; i < ROW - 1; i++)
                    {
                        for (int j = 1; j < COL - 1; j++)
                        {

                            if (savepic[i][j] != -1)
                            {
                                MAP[i][j] = 1;
                                if (leftright)
                                {
                                    AddPikachu(savepic[i][j], POS[i][j], CELL_WIDH, CELL_HEIGHT);
                                }
                                else
                                {
                                    AddPikachu2(savepic[i][j], POS[i][j], CELL_WIDH, CELL_HEIGHT);
                                }
                            }
                            else
                            {
                                MAP[i][j] = -1;
                                AddPikachu(995, POS[i][j], CELL_WIDH, CELL_HEIGHT);
                            }


                        }
                    }
                    CheckAndSwapThings1();

                    //Debug.Log("diem 1 :" + POS1.R.ToString() + " va " + POS1.C.ToString() + "diem 2 :" + POS2.R.ToString() + " va " + POS2.C.ToString()) ;
                }
                else
                {
                    // Debug.Log("khong thay dương di ");

                    Vector3 getpostx = new Vector3(MIN_X + POS1.C * CELL_WIDH + CELL_WIDH / 2, MIN_Y + POS1.R * CELL_HEIGHT + CELL_HEIGHT / 2, 10f);
                    if (leftright)
                    {
                        AddPikachu(savepic[POS1.R][POS1.C], getpostx, CELL_WIDH, CELL_HEIGHT);
                    }
                    else
                    {
                        AddPikachu2(savepic[POS1.R][POS1.C], getpostx, CELL_WIDH, CELL_HEIGHT);
                    }
                    POS1 = null;
                    POS2 = null;
                    soundRong.Play();
                }
            //  System.Threading.Thread.Sleep(3000);

        }
        // drawALine();
    }
	// Kiểm tra xem có đường đi hay k ?
	public bool checkSame(Vec2 post1, Vec2 post2)
	{
		
		if(savepic[post1.R][post1.C] == savepic[post2.R][post2.C])
		{
			return true;
		}
		
		return false;
	}
    public bool TraiTimBenLeCuaBangKieu(Vec2 post1, Vec2 post2)
	{
        if (post1.C == 0 || post2.C == 0 || post1.C == 15 || post2.C == 15 || post1.R == 0 || post2.R == 0 || post1.R == 9 || post2.R == 9)
		{
			return false;
		}
		
		return true;
	}
	public LPath CheckpairOnly(Vec2 v0, Vec2 v1)
	{
		ResetShit();
		SetShit(v0, true);
		return CheckShit(v1, true);
	}
	public void ResetShit()
	{
		for (int i = 0; i < ROW; i++)
			for (int j = 0; j < COL; j++)
				if (SHIT[i][j] == true) SHIT[i][j] = false;
	}
	public void SetShit(Vec2 v, bool isneedtotrack = false)
	{
		POS1_SAVE = new Vec2(v.R, v.C);
		SHIT[v.R][v.C] = true;
		//Debug.Log("(" + v.R + "," + v.C);
		int nc, nr;
		
		for (int k = 0; k < 2; k++)
		{
			for (int l = 1; l < 16; l++)
			{
				nr = v.R + l * D[k];
				if (nr < 0 || nr >= ROW) break;
				if (MAP[nr][v.C] != -1) break;
				// if (SHIT[nr][v.C]==false)
				{
					SHIT[nr][v.C] = true;
					if (isneedtotrack)
						SHIT_ROOT_POS[nr][v.C].R = -1;
					//Debug.Log("(" + nr + "," + v.C );
					SetShitHorizontal(new Vec2(nr, v.C), isneedtotrack);
				}
			}
		}
		
		for (int k = 0; k < 2; k++)
		{
			for (int l = 1; l < 15; l++)
			{
				nc = v.C + l * D[k];
				if (nc < 0 || nc >= COL) break;
				if (MAP[v.R][nc] != -1) break;
				//if (SHIT[v.R][nc]==false)
				{
					SHIT[v.R][nc] = true;
					if (isneedtotrack)
						SHIT_ROOT_POS[v.R][nc].R = -1;
					//Debug.Log("(" + v.R + "," + nc );
					SetShitVerticle(new Vec2(v.R, nc), isneedtotrack);
				}
			}
		}



	}
	public void SetShitHorizontal(Vec2 v, bool isneedtotrack = false)
	{
		int nc;
		for (int k = 0; k < 2; k++)
		{
			for (int l = 1; l < 15; l++)
			{
				nc = v.C + l * D[k];
				if (nc < 0 || nc >= COL) break;
				if (MAP[v.R][nc] != -1) break;
				if (SHIT[v.R][nc] == false)
				{
					SHIT[v.R][nc] = true;
					//Debug.Log("(" + v.R + "," + nc +"_ horifrom :" + v.Print());
					if (isneedtotrack)
					{
						SHIT_ROOT_POS[v.R][nc].R = v.R;
						SHIT_ROOT_POS[v.R][nc].C = v.C;
					}
				}
			}
		}
	}
	public void SetShitVerticle(Vec2 v, bool isneedtotrack = false)
	{
		int nr;
		for (int k = 0; k < 2; k++)
		{
			for (int l = 1; l < 16; l++)
			{
				nr = v.R + l * D[k];
				if (nr < 0 || nr >= ROW) break;
				if (MAP[nr][v.C] != -1) break;
				if (SHIT[nr][v.C] == false)
				{
					SHIT[nr][v.C] = true;
					//Debug.Log("(" + nr + "," + v.C + "_ verfrom :" + v.Print());
					if (isneedtotrack)
					{
						SHIT_ROOT_POS[nr][v.C].R = v.R;
						SHIT_ROOT_POS[nr][v.C].C = v.C;
					}
				}
			}
		}
	}
	public LPath CheckShit(Vec2 v, bool is_slow = false)
	{
		//Debug.Log("asd");
		bool b = false;
		if (is_slow) b = CheckShit_Slow(v);
		else b = (CheckShit_Fast(v));

		if (b) {
			//Debug.Log("annnnnnnnnnnnnnnnnnnnnnnnnnnsd");
			if (POS1_SAVE.R == v.R && POS_SAVE_MIDDLE.R == v.R)
				return new LPath (new Vec2 (POS1_SAVE.R, POS1_SAVE.C), new Vec2 (v.R, v.C));
			if (POS1_SAVE.C == v.C && POS_SAVE_MIDDLE.C == v.C)
				return new LPath (new Vec2 (POS1_SAVE.R, POS1_SAVE.C), new Vec2 (v.R, v.C));
			
			if (POS1_SAVE.R == POS_SAVE_MIDDLE.R || POS1_SAVE.C == POS_SAVE_MIDDLE.C)
				return new LPath (new Vec2 (POS1_SAVE.R, POS1_SAVE.C), new Vec2 (POS_SAVE_MIDDLE.R, POS_SAVE_MIDDLE.C), new Vec2 (v.R, v.C));
			
			
			return new LPath (new Vec2 (POS1_SAVE.R, POS1_SAVE.C),
			                  SHIT_ROOT_POS [POS_SAVE_MIDDLE.R] [POS_SAVE_MIDDLE.C],
			                  new Vec2 (POS_SAVE_MIDDLE.R, POS_SAVE_MIDDLE.C),
			                  new Vec2 (v.R, v.C));
			
			
		} 
		return null;
	}
	public bool CheckShit_Slow(Vec2 v)
	{
		int dx = 0;
		int dy = 0;
		//bool b = false;
		if (POS1.R == v.R)
		{
			//Debug.Log("11111111111111111111");
			dx = 0; dy = 1;
			if (CheckShit_Slow_Child(v, dx, dy)) return true;
			dx = 0; dy = -1;
			if (CheckShit_Slow_Child(v, dx, dy)) return true;
			dx = 1; dy = 0;
			if (CheckShit_Slow_Child(v, dx, dy)) return true;
			dx = -1; dy = 0;
			if (CheckShit_Slow_Child(v, dx, dy)) return true;
		}
		else if (POS1.C == v.C)
		{
		//	Debug.Log("222222222222222222222");
			dx = 1; dy = 0;
			if (CheckShit_Slow_Child(v, dx, dy)) return true;
			dx = -1; dy = 0;
			if (CheckShit_Slow_Child(v, dx, dy)) return true;
			dx = 0; dy = 1;
			if (CheckShit_Slow_Child(v, dx, dy)) return true;
			dx = 0; dy = -1;
			if (CheckShit_Slow_Child(v, dx, dy)) return true;
		}
		else
			return CheckShit_Fast(v, true);
		return false;
	}             
	public bool CheckShit_Fast(Vec2 v, bool is_find_best_way = false)
	{
		int nr, nc;
		CheckShit_Fast_temp = null;
		for (int k = 0; k < 4; k++)
		{
			for (int l = 1; l < 15; l++)
			{
				nr = v.R + l * DY[k];
				nc = v.C + l * DX[k];
				//Debug.Log(nr + " " + nc);
				if (nr < 0 || nr >= ROW || nc < 0 || nc >= COL) break;
				
				if (MAP[nr][nc] != -1) break;
				if (SHIT[nr][nc] == true)
				{
					if (is_find_best_way == false || SHIT_ROOT_POS[nr][nc].R == -1)
					{
						POS_SAVE_MIDDLE = new Vec2(nr, nc);
						return true;
					}
					else if (CheckShit_Fast_temp == null)
					{
						CheckShit_Fast_temp = new Vec2(nr, nc);
					}
				}
			}
		}
		if (CheckShit_Fast_temp != null)
		{
			POS_SAVE_MIDDLE = new Vec2(CheckShit_Fast_temp.R, CheckShit_Fast_temp.C);
			return true;
		}
		return false;
	}

    public bool CheckShit_Fast1(Vec2 v, bool is_find_best_way = false)
    {
        int nr, nc;
        CheckShit_Fast_temp = null;
        for (int k = 0; k < 4; k++)
        {
            for (int l = 1; l < 15; l++)
            {
                nr = v.R + l * DY[k];
                nc = v.C + l * DX[k];
                //Debug.Log(nr + " " + nc);
                if (nr < 0 || nr >= ROW || nc < 0 || nc >= COL) break;

                if (MAP[nr][nc] != -1) break;
                if (SHIT[nr][nc] == true)
                {
                    if (is_find_best_way == false || SHIT_ROOT_POS[nr][nc].R == -1)
                    {
                        //POS_SAVE_MIDDLE = new Vec2(nr, nc);
                        return true;
                    }
                    else if (CheckShit_Fast_temp == null)
                    {
                        CheckShit_Fast_temp = new Vec2(nr, nc);
                    }
                }
            }
        }
        if (CheckShit_Fast_temp != null)
        {
            POS_SAVE_MIDDLE = new Vec2(CheckShit_Fast_temp.R, CheckShit_Fast_temp.C);
            return true;
        }
        return false;
    }

	public bool CheckShit_Slow_Child(Vec2 v, int dx, int dy)
	{
		int nr, nc;
		for (int l = 1; l < 15; l++)
		{
			//Debug.Log("slow");
			nr = v.R + l * dx;
			nc = v.C + l * dy;
			if (nr < 0 || nr >= ROW || nc < 0 || nc >= COL) break;
			if (nr == POS1.R && nc == POS1.C)
			{
				POS_SAVE_MIDDLE = new Vec2(POS1.R, POS1.C);
				return true;
			}
			if (MAP[nr][nc] != -1) break;
			if (SHIT[nr][nc] == true)
			{
				//Debug.Log("slow222222222");
				POS_SAVE_MIDDLE = new Vec2(nr, nc);
				return true;
			}
		}
		return false;
	}
	// kiểm tra máp có đường đi hay k 
	public void CheckAndSwapThings()
	{
		while (CheckIsAvailable() == false)
		{
			Debug.Log("CheckAndSwapThings(): ResetMap here");
			ResetMap();
		}

        Vector3 posHint1 = new Vector3(MIN_X + HINT_POS0.C * CELL_WIDH + CELL_WIDH / 2, MIN_Y + HINT_POS0.R * CELL_HEIGHT + CELL_HEIGHT / 2, 10f);
        Vector3 posHint2 = new Vector3(MIN_X + HINT_POS1.C * CELL_WIDH + CELL_WIDH / 2, MIN_Y + HINT_POS1.R * CELL_HEIGHT + CELL_HEIGHT / 2, 10f);

        AddPikachu(993, posHint1, CELL_WIDH, CELL_HEIGHT);
        AddPikachu(993, posHint2, CELL_WIDH, CELL_HEIGHT);
		
	}
    public void CheckAndSwapThings1()
    {
       // while (CheckIsAvailable1() == false)
       // {
       //     ResetMap();
       // }
    }
	
	public bool CheckIsAvailable()
	{
		tcount = 0;
		// CoundAndLog();
		HINT_POS0 = null;
		HINT_POS1 = null;
		for (int i = 1; i < ROW - 1; i++)
			for (int j = 1; j < COL - 1; j++)
		{
			if (MAP[i][j] != -1)
			{
				tcount++;
				//tcount++;
				ResetShit();
				SetShit(new Vec2(i, j), true);
				
				for (int i2 = 1; i2 < ROW - 1; i2++)
					for (int j2 = 1; j2 < COL - 1; j2++)
				{
					if (i2 <= i && j2 <= j) continue;
					if (MAP[i2][j2] == MAP[i][j])
						if (CheckShit_Fast(new Vec2(i2, j2)) && savepic[i][j] == savepic[i2][j2])
					{
						HINT_POS0 = new Vec2(i, j);
						HINT_POS1 = new Vec2(i2, j2);
						return true;
					}
				}
			}
		}
		//Debug.Log("tcount=" + tcount);
		if (tcount == 0)
		{
			//ItemManager.I.YouWin();
			return true;
		}
		return false;
	}

    public bool CheckIsAvailable1()
    {
        tcount = 0;
        // CoundAndLog();
        HINT_POS0 = null;
        HINT_POS1 = null;
        for (int i = 1; i < ROW - 1; i++)
            for (int j = 1; j < COL - 1; j++)
            {
                if (MAP[i][j] != -1)
                {
                    tcount++;
                    //tcount++;
                    ResetShit();
                    SetShit(new Vec2(i, j), true);

                    for (int i2 = 1; i2 < ROW - 1; i2++)
                        for (int j2 = 1; j2 < COL - 1; j2++)
                        {
                            if (i2 <= i && j2 <= j) continue;
                            if (MAP[i2][j2] == MAP[i][j])
                                if (CheckShit_Fast1(new Vec2(i2, j2)) && savepic[i][j] == savepic[i2][j2])
                                {
                                    HINT_POS0 = new Vec2(i, j);
                                    HINT_POS1 = new Vec2(i2, j2);
                                    return true;
                                }
                        }
                }
            }
        //Debug.Log("tcount=" + tcount);
        if (tcount == 0)
        {
            //ItemManager.I.YouWin();
            return true;
        }
        return false;
    }
    public void ResetMap()
    {
        int dem = (ROW-2)*(COL-2);
       int[] savePicOne = new int[dem];
          for (int i = 0; i < dem; i++)
       {
           savePicOne[i] =-1;
       }
       for (int i = 1; i < ROW - 1; i++)
       {
           for (int j = 1; j < COL - 1; j++)
           {
               if (savepic[i][j] != -1)
               {

                   savePicOne[j + (i-1) * 14-1] = savepic[i][j];
               }
           }
       }
        int end =0;
       for (int i = 0; i < dem; i++)
       {
           int index1 = Random.Range(0, dem);
           int index2 = Random.Range(0, dem);
           do
           {
               do
               {
                   index1 = Random.Range(0, dem);
               }
               while (savePicOne[index1] == -1);

               do
               {
                   index2 = Random.Range(0, dem);
               }
               while (savePicOne[index2] == -1);

               end++;

           }
           while (end < 10 && savePicOne[index1] == savePicOne[index2]);
          
           
               int temp = savePicOne[index1];
               savePicOne[index1] = savePicOne[index2];
               savePicOne[index2] = temp;
        
           
           
       }
      

       

       for (int i = 1; i < ROW - 1; i++)
       {
           for (int j = 1; j < COL - 1; j++)
           {

               savepic[i][j] = savePicOne[j + (i - 1) * 14 - 1];
             //Debug.Log("O thu " + (j + (i) * COL).ToString() + " = "+ savepic[i][j].ToString());
           }
       }

       for (int i = 1; i < ROW - 1; i++)
       {
           for (int j = 1; j < COL - 1; j++)
           {

               if (savepic[i][j] != -1)
               {
                   MAP[i][j] = 1;
                   if (leftright)
                   {
                       AddPikachu(savepic[i][j], POS[i][j], CELL_WIDH, CELL_HEIGHT);
                   }
                   else
                   {
                       AddPikachu2(savepic[i][j], POS[i][j], CELL_WIDH, CELL_HEIGHT);
                   }
               }
               else
               {
                   MAP[i][j] = -1;
                   AddPikachu(995, POS[i][j], CELL_WIDH, CELL_HEIGHT);
               }


           }
       }
    }
    //--- draw Line
    public IEnumerator DoTheDance()
    {
        trigger = false;
        yield return new WaitForSeconds(2f); // waits 3 seconds
        trigger = true; // will make the update method pick up 
    }
     void UseLandscapeLeftLayout()
     {
         for (int i = 1; i < ROW - 1; i++)
         {
             for (int j = 1; j < COL - 1; j++)
             {
                 if (MAP[i][j] == 1)
                 {
                     AddPikachu(savepic[i][j], POS[i][j], CELL_WIDH, CELL_HEIGHT);
                 }
                 else AddPikachu(995, POS[i][j], CELL_WIDH, CELL_HEIGHT);
             }
         }
         ramdomFreeModex = ramdomFreeMode;
         ramdomBackModex = ramdomBackMode;
         ramdomSoundModex = ramdomSoundMode;
         ramdomSeeModex = ramdomSeeMode;
         ramdomSoundOffx = ramdomSoundOff;

         number00 = number0;
         number10 = number1;
         number20 = number2;
         number30 = number3;
     }
     void UsePortraitLayout()
     {
         for (int i = 1; i < ROW - 1; i++)
         {
             for (int j = 1; j < COL - 1; j++)
             {
                 if (MAP[i][j] == 1)
                 {
                     AddPikachu2(savepic[i][j], POS[i][j], CELL_WIDH, CELL_HEIGHT);
                 }
                 else AddPikachu2(995, POS[i][j], CELL_WIDH, CELL_HEIGHT);
             }
         }

         ramdomFreeModex = ramdomFreeMode2;
         ramdomBackModex = ramdomBackMode2;
         ramdomSoundModex = ramdomSoundMode2;
         ramdomSeeModex = ramdomSeeMode2;
         ramdomSoundOffx = ramdomSoundOff2;

         number00 = number0x;
         number10 = number1x;
         number20 = number2x;
         number30 = number3x;
     }
     void drawALine()
     {

         // point 1 
         float x1, y1;
         x1 = POS1.C * CELL_WIDH + MIN_X;
         y1 = POS1.R * CELL_HEIGHT + MIN_Y;
         x1 = x1 / size;
         y1 = -y1 / size;
         float positionx, positiony;
         positionx = (x1 * Screen.width) / (Screen.width * 1.0f / Screen.height) + Screen.width / 2 + CELL_WIDH;
         positiony = (y1 * Screen.height) + Screen.height / 2 - CELL_HEIGHT;
         //point 2
         float x2, y2, b, b2, a, a2;
         x2 = POS_SAVE_MIDDLE.C * CELL_WIDH + MIN_X;
         y2 = POS_SAVE_MIDDLE.R * CELL_HEIGHT + MIN_Y;
         b = 1 * CELL_HEIGHT + MIN_Y;
         b2 = 8 * CELL_HEIGHT + MIN_Y;

         a = 1 * CELL_WIDH + MIN_X;
         a2 = 14 * CELL_WIDH + MIN_X;
         x2 = x2 / size;
         y2 = -y2 / size;
         b = -b / size;
         b2 = -b2 / size;
         a = a / size;
         a2 = a2 / size;

         float positionx2, positiony2, positionyb, positionyb2, positionya, positionya2;
         positionx2 = (x2 * Screen.width) / (Screen.width * 1.0f / Screen.height) + Screen.width / 2 + CELL_WIDH;
         positiony2 = (y2 * Screen.height) + Screen.height / 2 - CELL_HEIGHT;
         positionyb = (b * Screen.height) + Screen.height / 2 - CELL_HEIGHT;
         positionyb2 = (b2 * Screen.height) + Screen.height / 2 - CELL_HEIGHT;
         positionya = (a * Screen.width) / (Screen.width * 1.0f / Screen.height) + Screen.width / 2 + CELL_WIDH;
         positionya2 = (a2 * Screen.width) / (Screen.width * 1.0f / Screen.height) + Screen.width / 2 + CELL_WIDH;
         if (POS_SAVE_MIDDLE.R == 0)
         {

             positiony2 -= (positiony2 - positionyb) / 3;

         }

         if (POS_SAVE_MIDDLE.R == 9)
         {

             positiony2 += (-positiony2 + positionyb2) / 3;
         }
         if (POS_SAVE_MIDDLE.C == 0)
         {

             positionx2 += (-positionx2 + positionya) / 3;

         }

         if (POS_SAVE_MIDDLE.C == 15)
         {

             positionx2 -= (positionx2 - positionya2) / 3;
         }

         // point 3
         float x3, y3;
         x3 = POS2.C * CELL_WIDH + MIN_X;
         y3 = POS2.R * CELL_HEIGHT + MIN_Y;
         x3 = x3 / size;
         y3 = -y3 / size;
         float positionx3, positiony3;
         positionx3 = (x3 * Screen.width) / (Screen.width * 1.0f / Screen.height) + Screen.width / 2 + CELL_WIDH;
         positiony3 = (y3 * Screen.height) + Screen.height / 2 - CELL_HEIGHT;
         // draw 3 line 
         Vector2 point1 = new Vector2(positionx, positiony);
         Vector2 point2 = new Vector2(positionx2, positiony2);
         Vector2 point3 = new Vector2(positionx3, positiony3);
         Vector2 point4;
         if (POS2.C == POS_SAVE_MIDDLE.C)
         {
             point4 = new Vector2(positionx, positiony2);
         }
         else
         {
             point4 = new Vector2(positionx2, positiony);
         }
         //            Vector2 pointCenter = new Vector2(Screen.width/2, Screen.height/2);
         Drawling.DrawLine(point1, point4, color, width);
         Drawling.DrawLine(point2, point4, color, width);
         Drawling.DrawLine(point2, point3, color, width);
         current = Time.time;

         if (current - currentold > 0.3f)
         {
             POS1 = null;
             POS2 = null;
             // currentold = current;
         }

     }
     void particleSystem()
     {
         float x3, y3;
         x3 = 1 * CELL_WIDH + MIN_X;
         y3 = 1 * CELL_HEIGHT + MIN_Y;
         x3 = x3 / size;
         y3 = -y3 / size;
         float positionx3, positiony3;
         positionx3 = (x3 * Screen.width) / (Screen.width * 1.0f / Screen.height) + Screen.width / 2 + CELL_WIDH;
         positiony3 = (y3 * Screen.height) + Screen.height / 2 - CELL_HEIGHT;

         SpecialEffectsHelper.Instance.Explosion(new Vector3(-6 * CELL_HEIGHT - CELL_HEIGHT / 2 + (POS1.C - 1) * CELL_HEIGHT, -4 * CELL_HEIGHT + CELL_HEIGHT / 2 + (POS1.R - 1) * CELL_HEIGHT, 0f));
         SpecialEffectsHelper.Instance.Explosion(new Vector3(-6 * CELL_HEIGHT - CELL_HEIGHT / 2 + (POS2.C - 1) * CELL_HEIGHT, -4 * CELL_HEIGHT + CELL_HEIGHT / 2 + (POS2.R - 1) * CELL_HEIGHT, 0f));
     }
	
}
